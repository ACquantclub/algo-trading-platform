'''
This file contains the PortfolioEvaluator class, which is responsible for evaluating the performance of a portfolio allocation algorithm.
'''

import numpy as np
import pandas as pd
from typing import Callable
import importlib.util
import sys

class PortfolioEvaluator:
    def __init__(self, market_data: dict[str, pd.DataFrame], returns: pd.DataFrame):
        """
        market_data: Dictionary containing DataFrames for different data types:
            - 'open': Opening prices
            - 'close': Closing prices
            - 'high': High prices
            - 'low': Low prices
            - 'volume': Trading volumes
        All DataFrames must have datetime index and columns as asset names
        """
        required_fields = ['open', 'close', 'high', 'low', 'volume']
        if not all(field in market_data for field in required_fields):
            raise ValueError(f"market_data must contain all fields: {required_fields}")
        
        self.market_data = market_data
        self.returns = returns

    def _validate_and_normalize(self, weights: np.ndarray) -> np.ndarray:
        """Validate and normalize weights"""
        if len(weights) != len(self.market_data['close'].columns):
            raise ValueError("Invalid weight vector length")
        
        if np.any(weights < 0):
            raise ValueError("Weights must be non-negative")
        return weights / np.sum(np.abs(weights))

    def evaluate_strategy(self, strategy_class: type) -> dict:
        """Run strategy and calculate comprehensive performance metrics"""
        try:
            n_periods = len(self.market_data['close']) - 1
            n_assets = len(self.market_data['close'].columns)
            weights_history = np.zeros((n_periods, n_assets))

            # Create single instance of strategy class
            strategy_instance = strategy_class()

            # Prepare market data arrays
            market_arrays = {
                field: data.values for field, data in self.market_data.items()
            }

            # Get allocation for each time step
            for t in range(n_periods):
                current_data = {
                    field: arrays[t] for field, arrays in market_arrays.items()
                }
                try:
                    weights = strategy_instance.allocate(current_data)
                except Exception as e:
                    raise RuntimeError(f"Error in strategy allocate() method: {str(e)}")
                if not isinstance(weights, np.ndarray):
                    weights = np.array(weights)

                try:    
                    weights_history[t] = self._validate_and_normalize(weights)
                except Exception as e:
                    raise ValueError(f"Error in strategy weights: {str(e)}")

            weights_df = pd.DataFrame(
                weights_history, 
                index=self.returns.index, 
                columns=self.market_data['close'].columns
            )

            # Calculate daily portfolio returns
            portfolio_returns = np.sum(weights_df.values * self.returns.values, axis=1)
            portfolio_returns = pd.Series(portfolio_returns, index=self.returns.index)
            
            # Calculate cumulative returns
            cumulative_returns = (1 + portfolio_returns).cumprod()
            
            # Calculate drawdown series
            rolling_max = cumulative_returns.expanding().max()
            drawdowns = cumulative_returns / rolling_max - 1
            
            # Calculate risk metrics
            excess_returns = portfolio_returns - 0.02/252  # Assuming 2% risk-free rate
            negative_returns = portfolio_returns[portfolio_returns < 0]
            
            metrics = {
                "sharpe_ratio": portfolio_returns.mean() / portfolio_returns.std(),
                "sortino_ratio": excess_returns.mean() / negative_returns.std(),
                "max_drawdown": drawdowns.min(),
                "volatility": portfolio_returns.std(),
                "annual_return": np.prod(1 + portfolio_returns) - 1,
                "calmar_ratio": (np.prod(1 + portfolio_returns) - 1) / abs(drawdowns.min()),
                "win_rate": len(portfolio_returns[portfolio_returns > 0]) / len(portfolio_returns),
                "returns": portfolio_returns,
                "weights": weights_df,
                "cumulative_returns": cumulative_returns,
                "drawdown_series": drawdowns,
            }
            
            # Calculate rolling metrics
            WINDOW = 63  # ~3 months
            metrics.update({
                "rolling_sharpe": portfolio_returns.rolling(WINDOW).mean() / 
                                portfolio_returns.rolling(WINDOW).std() * np.sqrt(252),
                "rolling_volatility": portfolio_returns.rolling(WINDOW).std() * np.sqrt(252),
                "rolling_var_95": portfolio_returns.rolling(WINDOW).quantile(0.05),
            })
            
            return metrics
        except Exception as e:
            raise ValueError(f"Error evaluating strategy: {str(e)}")

    @staticmethod
    def load_submission(submission_path: str) -> type:
        """Load submitted strategy class"""
        if not submission_path.endswith(".py"):
            raise ValueError("Submission must be a Python file")

        spec = importlib.util.spec_from_file_location("submission", submission_path)
        if spec is None or spec.loader is None:
            raise ImportError("Could not load submission file")

        module = importlib.util.module_from_spec(spec)
        sys.modules["submission"] = module
        spec.loader.exec_module(module)

        # Look for a class that has an allocate method
        strategy_class = None
        for name, obj in module.__dict__.items():
            if isinstance(obj, type) and hasattr(obj, 'allocate'):
                strategy_class = obj
                break

        if strategy_class is None:
            raise ValueError("Missing strategy class with allocate method")

        return strategy_class
